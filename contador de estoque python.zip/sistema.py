from estoque import Estoque  
class Sistema:
    def __init__(self):
        self._estoque = Estoque()  

    def menu(self):
        print("\n" + "=" * 45)
        print("     🏪 SISTEMA DE CONTROLE DE ESTOQUE")
        print("=" * 45)
        print("  [1] Cadastrar produto")
        print("  [2] Listar produtos")
        print("  [3] Atualizar quantidade")
        print("  [4] Remover produto")
        print("  [5] Buscar produto por nome")
        print("  [6] Ver produtos com estoque baixo")
        print("  [0] Sair")
        print("=" * 45)

    def executar(self):
        print("\n  Bem-vindo ao Sistema de Controle de Estoque!")

        while True:  
            self.menu()  
            opcao = input("  👉 Escolha uma opção: ").strip()

            if opcao == "1":
                self._cadastrar_produto()

            elif opcao == "2":
                self._estoque.listar_produtos()

            elif opcao == "3":
                self._atualizar_quantidade()

            elif opcao == "4":
                self._remover_produto()

            elif opcao == "5":
                self._buscar_produto()

            elif opcao == "6":
                self._ver_estoque_baixo()

            elif opcao == "0":
                print("\n  👋 Saindo do sistema. Até logo!")
                break  

            else:
                print("  ❌ Opção inválida. Digite um número entre 0 e 6.")

    def _cadastrar_produto(self):
        print("\n  --- CADASTRAR PRODUTO ---")
        nome = input("  Nome do produto : ").strip()

        if not nome:
            print("  ❌ Nome não pode ser vazio.")
            return

        try:
            preco = float(input("  Preço (R$)      : ").replace(",", "."))
            quantidade = int(input("  Quantidade      : "))

            if preco < 0 or quantidade < 0:
                print("  ❌ Preço e quantidade devem ser valores positivos.")
                return

        except ValueError:
            print("  ❌ Valor inválido. Preço deve ser número decimal e quantidade deve ser inteiro.")
            return

        self._estoque.adicionar_produto(nome, preco, quantidade)

    def _atualizar_quantidade(self):
        print("\n  --- ATUALIZAR QUANTIDADE ---")
        nome = input("  Nome do produto : ").strip()

        try:
            nova_quantidade = int(input("  Nova quantidade : "))
            if nova_quantidade < 0:
                print("  ❌ Quantidade não pode ser negativa.")
                return
        except ValueError:
            print("  ❌ Quantidade inválida. Digite um número inteiro.")
            return

        self._estoque.atualizar_quantidade(nome, nova_quantidade)

    def _remover_produto(self):
        print("\n  --- REMOVER PRODUTO ---")
        nome = input("  Nome do produto a remover: ").strip()
        confirmacao = input(f"  Tem certeza que deseja remover '{nome}'? (s/n): ").strip().lower()

        if confirmacao == "s":
            self._estoque.remover_produto(nome)
        else:
            print("  ↩️  Remoção cancelada.")

    def _buscar_produto(self):
        print("\n  --- BUSCAR PRODUTO ---")
        nome = input("  Nome do produto : ").strip()
        produto = self._estoque.buscar_produto(nome)

        if produto is not None:
            print("\n  ✅ Produto encontrado:")
            print("  " + "-" * 35)
            produto.exibir_dados()
        else:
            print(f"  ❌ Produto '{nome}' não encontrado no estoque.")

    def _ver_estoque_baixo(self):
        print("\n  --- ESTOQUE BAIXO ---")
        try:
            limite = int(input("  Limite mínimo de unidades (padrão 5): ").strip() or "5")
        except ValueError:
            limite = 5

        self._estoque.mostrar_estoque_baixo(limite)
