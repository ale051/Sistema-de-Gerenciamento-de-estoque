from produto import Produto 

class Estoque:
    def __init__(self):
        self._produtos = []  

    def adicionar_produto(self, nome, preco, quantidade):
        if self.buscar_produto(nome) is not None:
            print(f"⚠️  Produto '{nome}' já existe no estoque. Use 'Atualizar' para modificá-lo.")
            return

        novo_produto = Produto(nome, preco, quantidade)
        self._produtos.append(novo_produto)
        print(f"✅ Produto '{nome}' cadastrado com sucesso!")

    def remover_produto(self, nome):
        produto = self.buscar_produto(nome)

        if produto is None:
            print(f"❌ Produto '{nome}' não encontrado no estoque.")
            return

        self._produtos.remove(produto)
        print(f"✅ Produto '{nome}' removido com sucesso!")

    def listar_produtos(self):
        if len(self._produtos) == 0:
            print("📭 O estoque está vazio. Nenhum produto cadastrado.")
            return

        print("\n" + "=" * 45)
        print("         📋 LISTA DE PRODUTOS")
        print("=" * 45)

        for produto in self._produtos:
            produto.exibir_dados()  

        print(f"  Total de produtos: {len(self._produtos)}")
        print("=" * 45)

    def buscar_produto(self, nome):
        for produto in self._produtos:
            if produto.get_nome().lower() == nome.lower():
                return produto  
        return None  

    def atualizar_quantidade(self, nome, nova_quantidade):
        produto = self.buscar_produto(nome)

        if produto is None:
            print(f"❌ Produto '{nome}' não encontrado no estoque.")
            return

        produto.atualizar_quantidade(nova_quantidade)

    def mostrar_estoque_baixo(self, limite=5):
        produtos_baixos = []

        for produto in self._produtos:
            if produto.get_quantidade() <= limite:
                produtos_baixos.append(produto)

        if len(produtos_baixos) == 0:
            print(f"✅ Nenhum produto com estoque abaixo de {limite} unidades.")
            return

        print("\n" + "=" * 45)
        print(f"   ⚠️  PRODUTOS COM ESTOQUE BAIXO (≤ {limite})")
        print("=" * 45)

        for produto in produtos_baixos:
            produto.exibir_dados()

        print("=" * 45)
