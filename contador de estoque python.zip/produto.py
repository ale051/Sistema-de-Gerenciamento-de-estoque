class Produto:
    
    def __init__(self, nome, preco, quantidade):
       
        self._nome = nome            
        self._preco = preco          
        self._quantidade = quantidade  

    def get_nome(self):
        return self._nome

    def get_preco(self):
        return self._preco

    def get_quantidade(self):
        return self._quantidade


    def set_preco(self, novo_preco):
        self._preco = novo_preco


    def atualizar_quantidade(self, nova_quantidade):
        self._quantidade = nova_quantidade
        print(f"✅ Quantidade do produto '{self._nome}' atualizada para {nova_quantidade}.")

    def exibir_dados(self):
        print(f"  📦 Nome     : {self._nome}")
        print(f"     Preço    : R$ {self._preco:.2f}")
        print(f"     Quantidade: {self._quantidade} unidades")
        print("  " + "-" * 35)
